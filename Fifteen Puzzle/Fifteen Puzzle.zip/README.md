Submission from Matthew Callahan and  Suphalerk Lortaraprasert.

To run the code, run the command:
> python main.py
in your terminal. This will run the comparison for a single heuristic. To change the heuristic tested requires editing the code.

we used python version 3.10.12



